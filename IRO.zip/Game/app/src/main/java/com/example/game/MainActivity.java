package com.example.game;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private ConstraintLayout layout;
    private Button buttonColor;


    public static final int CAMERA_ACTION_CODE = 12;
    Button result;
    ImageView imageView;
    ImageView imageViewtarget;
    TextView imagecolortarget;
    TextView textView;
    View viewColor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imagecolortarget=findViewById(R.id.imageColorCode);
        imageViewtarget=findViewById(R.id.imageColor);


        imageViewtarget.setOnTouchListener(new ImageView.OnTouchListener(){
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // TODO Auto-generated method stub
                int x=0;
                int y=0;
                imagecolortarget.setText("Touch coordinates : " +
                       String.valueOf(event.getX()) + "x" + String.valueOf(event.getY()));
                ImageView imageView = ((ImageView)v);
                Bitmap bitmap = ((BitmapDrawable)imageView.getDrawable()).getBitmap();
                int pixel = bitmap.getPixel(x,y);
                int redValue = Color.red(pixel);
                int blueValue = Color.blue(pixel);
                int greenValue = Color.green(pixel);





                return true;    }
        });

        layout = findViewById(R.id.layout);
        buttonColor = findViewById(R.id.buttonColor);

        buttonColor.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v1){
                Random random = new Random();
                int color = Color.argb(255, random.nextInt(256), random.nextInt(256), random.nextInt(256));
                layout.setBackgroundColor(color);
            }
        });



        Button buttonCap = (Button) findViewById(R.id.buttonCap);
        imageView = findViewById(R.id.previewImage);
        buttonCap.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent();
                intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
                if (getApplicationContext().getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_CAMERA_ANY)) {
                    // this device has a camera
                    startActivityForResult(intent, CAMERA_ACTION_CODE);
                } else {
                    Toast.makeText(MainActivity.this, "There is no app that support this action", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CAMERA_ACTION_CODE && resultCode == RESULT_OK && data != null){
            Bundle bundle = data.getExtras();
            Bitmap finalPhoto = (Bitmap) bundle.get("data");
            imageView.setImageBitmap(finalPhoto);

        }
    }

}